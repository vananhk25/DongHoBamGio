
import React, { useState } from 'react';
import { Text, View, StyleSheet, TouchableOpacity } from 'react-native';

export default function Stopwatch() {
  const [time, setTime] = useState({ minutes: 0, seconds: 0, milliseconds: 0 });
  const [timer, setTimer] = useState(null);
  const [laps, setLaps] = useState([]);

  const startTimer = () => {
    if (!timer) {
      setTimer(setInterval(updateTimer, 10));
    }
  };

  const stopTimer = () => {
    clearInterval(timer);
    setTimer(null);
  };

  const resetTimer = () => {
    clearInterval(timer);
    setTimer(null);
    setTime({ minutes: 0, seconds: 0, milliseconds: 0 });
    setLaps([]);
  };

  const updateTimer = () => {
    setTime((prevTime) => {
      let milliseconds = prevTime.milliseconds + 10;
      let seconds = prevTime.seconds;
      let minutes = prevTime.minutes;

      if (milliseconds === 1000) {
        milliseconds = 0;
        seconds++;

        if (seconds === 60) {
          seconds = 0;
          minutes++;
        }
      }

      return { minutes, seconds, milliseconds };
    });
  };

  const lapTimer = () => {
    setLaps((prevLaps) => [...prevLaps, time]);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.timer}>
        {time.minutes.toString().padStart(2, '0')}:
        {time.seconds.toString().padStart(2, '0')}:
        {time.milliseconds.toString().padStart(3, '0')}
      </Text>
      <View style={styles.buttonContainer}>
        <TouchableOpacity style={styles.button} onPress={startTimer}>
          <Text style={styles.buttonText}>Start</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={stopTimer}>
          <Text style={styles.buttonText}>Stop</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={resetTimer}>
          <Text style={styles.buttonText}>Reset</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={lapTimer}>
          <Text style={styles.buttonText}>Lap</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.lapsContainer}>
        {laps.map((lap, index) => (
          <Text key={index} style={styles.lapText}>
            Lap {index + 1}: {lap.minutes.toString().padStart(2, '0')}:
            {lap.seconds.toString().padStart(2, '0')}:
            {lap.milliseconds.toString().padStart(3, '0')}
          </Text>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  timer: {
    fontSize: 40,
    fontWeight: 'bold',
  },
  buttonContainer: {
    flexDirection: 'row',
    marginVertical: 20,
  },
  button: {
    marginHorizontal: 10,
    backgroundColor: 'lightblue',
    padding: 10,
    borderRadius: 5,
  },
  buttonText: {
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  lapsContainer: {
    marginTop: 20,
    alignItems: 'center',
  },
  lapText: {
    fontSize: 16,
    marginVertical: 5,
  },
});

